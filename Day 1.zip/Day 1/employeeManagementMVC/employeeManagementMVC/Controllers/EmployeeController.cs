﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using employeeManagementMVC.Models;
namespace employeeManagementMVC.Controllers
{
    public class EmployeeController : Controller
    {
       //we create the Action Methods

        public IActionResult Employee()
        {
            //here we collect data from Model
            //pass the same to view 
            //or reverse

            //some hard coded data -- this is suppose to come from Model - hard code is not a good practice
            ViewBag.totalEmployee = 10;
            ViewBag.teamName = "Development";
            ViewBag.client = "Some Bank";
            ViewBag.isBilled = true;

            List<string> empList = new List<string>() { "Nikhil", "Akshay", "karan", "Priya", "Riya", "Sumit","Rohan"};
            ViewBag.eList = empList;

                
            return View();
        }

        public IActionResult EmployeeDetails()
        {
            EmployeeModel empobj = new EmployeeModel();
            ViewBag.empDetails = empobj.GetEmpdetails();
            return View();
        }

        public IActionResult ApplyLeave()
        {
            return View();
        }

        public IActionResult EmployeeList()
        {
            return View();
        }

        public IActionResult WorkCulture()
        {
            return View();
        }
        public IActionResult Careers()
        {
            return View();
        }
    }
}