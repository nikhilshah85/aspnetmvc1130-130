﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace employeeManagementMVC.Models
{
    public class EmployeeModel
    {
        public int empNo { get; set; }
        public string empName { get; set; }
        public string empDesignation { get; set; }
        public double empSalary { get; set; }
        public bool empIsPermenant { get; set; }

        public EmployeeModel GetEmpdetails()
        {
            //connect to data source and get the data
            var emp = new EmployeeModel()
            {
                empNo = 101,
                empName = "Karan",
                empDesignation = "Sales",
                empIsPermenant = true,
                empSalary = 6000
            };
            return emp;
        }
    }
}
