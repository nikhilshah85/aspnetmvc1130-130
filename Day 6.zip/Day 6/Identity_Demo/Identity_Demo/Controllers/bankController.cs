﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Identity_Demo.Controllers
{
    [Authorize]
    public class bankController : Controller
    {
        [AllowAnonymous]
        public IActionResult OpenAccount()
        {
            return View();
        }

        public IActionResult Transfer()
        {
            return View();
        }

        public IActionResult BillPay()
        {
            return View();
        }

        public IActionResult ViewCreditCardDetails()
        {
            return View();
        }
    }
}