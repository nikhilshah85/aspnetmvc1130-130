﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DI_Demo.Models.InMemory
{
    public class Employee
    {
        public int empNo { get; set; }
        public string empName{ get; set; }
        public string empDesignation { get; set; }

        static List<Employee> empList = new List<Employee>()
        {
            new Employee(){ empNo=101, empName="Karan", empDesignation="Sales"},
            new Employee(){ empNo=102, empName="Mohan", empDesignation="Account"},
            new Employee(){ empNo=103, empName="Rohan", empDesignation="HR"},
        };

        public List<Employee> GetEmpList()
        {
            return empList;
        }

        public string Add(Employee newEmp)
        {
            empList.Add(newEmp);
            return "Employee Added";
        }
    }
}
