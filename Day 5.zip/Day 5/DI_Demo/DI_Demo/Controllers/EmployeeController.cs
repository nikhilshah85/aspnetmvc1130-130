﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using DI_Demo.Models.InMemory;
namespace DI_Demo.Controllers
{
    public class EmployeeController : Controller
    {

        Employee empObj;//this is developer createing the object

        //object created by runrime will be injected in this controller, when a new instance of
        //controller created
        public EmployeeController(Employee empObjRef)
        {
            empObj = empObjRef;
        }

        public IActionResult EmployeeList()
        {
            
            return View(empObj.GetEmpList());
        }

        public IActionResult AddEmployee()
        {
            return View();
        }

        public IActionResult AddEmployee(Employee newEmp)
        {
            empObj.Add(newEmp);
            return View();
        }
    }
}