﻿using System;
using System.Collections.Generic;

namespace DI_Demo.Model.DB
{
    public partial class Products
    {
        public Products()
        {
            Sales = new HashSet<Sales>();
        }

        public int PId { get; set; }
        public string PName { get; set; }
        public string PCategory { get; set; }

        public ICollection<Sales> Sales { get; set; }
    }
}
