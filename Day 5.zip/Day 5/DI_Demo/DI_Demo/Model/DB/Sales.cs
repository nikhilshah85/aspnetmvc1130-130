﻿using System;
using System.Collections.Generic;

namespace DI_Demo.Model.DB
{
    public partial class Sales
    {
        public int SId { get; set; }
        public int? SaleAmount { get; set; }
        public int? PId { get; set; }

        public Products P { get; set; }
    }
}
