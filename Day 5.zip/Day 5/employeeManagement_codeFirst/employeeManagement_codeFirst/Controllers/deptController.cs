﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using employeeManagement_codeFirst.Models;

namespace employeeManagement_codeFirst.Controllers
{
    public class deptController : Controller
    {
        private readonly EmployeeDBContext _context;

        public deptController(EmployeeDBContext context)
        {
            _context = context;
        }

        // GET: dept
        public async Task<IActionResult> Index()
        {
            return View(await _context.Department.ToListAsync());
        }

        // GET: dept/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var deptDetails = await _context.Department
                .FirstOrDefaultAsync(m => m.deptNo == id);
            if (deptDetails == null)
            {
                return NotFound();
            }

            return View(deptDetails);
        }

        // GET: dept/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: dept/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("deptNo,deptName,deptEmail,deptLocation,deptMobile")] DeptDetails deptDetails)
        {
            if (ModelState.IsValid)
            {
                _context.Add(deptDetails);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(deptDetails);
        }

        // GET: dept/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var deptDetails = await _context.Department.FindAsync(id);
            if (deptDetails == null)
            {
                return NotFound();
            }
            return View(deptDetails);
        }

        // POST: dept/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("deptNo,deptName,deptEmail,deptLocation,deptMobile")] DeptDetails deptDetails)
        {
            if (id != deptDetails.deptNo)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(deptDetails);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DeptDetailsExists(deptDetails.deptNo))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(deptDetails);
        }

        // GET: dept/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var deptDetails = await _context.Department
                .FirstOrDefaultAsync(m => m.deptNo == id);
            if (deptDetails == null)
            {
                return NotFound();
            }

            return View(deptDetails);
        }

        // POST: dept/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var deptDetails = await _context.Department.FindAsync(id);
            _context.Department.Remove(deptDetails);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DeptDetailsExists(int id)
        {
            return _context.Department.Any(e => e.deptNo == id);
        }
    }
}
