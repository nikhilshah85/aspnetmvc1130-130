﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace employeeManagement_codeFirst.Models
{
    public class EmployeeDBContext : DbContext
    {

        public DbSet<DeptDetails> Department { get; set; }
        public DbSet<Employee> EmployeeDetails { get; set; }

        public DbSet<Leavemanagement> Leaves { get; set; }
        public EmployeeDBContext(DbContextOptions options):base(options)
        {

        }


    }
}
