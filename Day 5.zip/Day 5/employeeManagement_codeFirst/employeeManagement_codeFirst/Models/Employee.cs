﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace employeeManagement_codeFirst.Models
{
    public class Employee
    {
        [Key]
        public int empNo { get; set; }
        public string empName { get; set; }
        public string empDesignation { get; set; }
        public double empSalary { get; set; }
        public bool empIsPermenant { get; set; }

        public string empEmailAddress { get; set; }
        public string empHighestEducation { get; set; }

    }
}
