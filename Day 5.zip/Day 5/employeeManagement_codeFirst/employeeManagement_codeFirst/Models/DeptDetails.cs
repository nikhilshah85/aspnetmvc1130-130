﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace employeeManagement_codeFirst.Models
{
    public class DeptDetails
    {
        [Key]
        public int deptNo { get; set; }
        public string deptName { get; set; }
        public string deptEmail { get; set; }
        public string deptLocation { get; set; }

        public long deptMobile { get; set; }
    }
}
