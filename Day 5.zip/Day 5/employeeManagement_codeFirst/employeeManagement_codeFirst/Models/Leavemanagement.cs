﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace employeeManagement_codeFirst.Models
{
    public class Leavemanagement
    {
        [Key]
        public int leaveId { get; set; }
        public int empNo { get; set; }
        public string leaveReason { get; set; }
        public int noOfDays { get; set; }
        public bool isLeaveApproved { get; set; }
    }
}
