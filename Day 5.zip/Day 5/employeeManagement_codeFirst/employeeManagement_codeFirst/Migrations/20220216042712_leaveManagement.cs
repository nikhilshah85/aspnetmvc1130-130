﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace employeeManagement_codeFirst.Migrations
{
    public partial class leaveManagement : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "empEmailAddress",
                table: "EmployeeDetails",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "empHighestEducation",
                table: "EmployeeDetails",
                nullable: true);

            migrationBuilder.AddColumn<long>(
                name: "deptMobile",
                table: "Department",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.CreateTable(
                name: "Leaves",
                columns: table => new
                {
                    leaveId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    empNo = table.Column<int>(nullable: false),
                    leaveReason = table.Column<string>(nullable: true),
                    noOfDays = table.Column<int>(nullable: false),
                    isLeaveApproved = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Leaves", x => x.leaveId);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Leaves");

            migrationBuilder.DropColumn(
                name: "empEmailAddress",
                table: "EmployeeDetails");

            migrationBuilder.DropColumn(
                name: "empHighestEducation",
                table: "EmployeeDetails");

            migrationBuilder.DropColumn(
                name: "deptMobile",
                table: "Department");
        }
    }
}
