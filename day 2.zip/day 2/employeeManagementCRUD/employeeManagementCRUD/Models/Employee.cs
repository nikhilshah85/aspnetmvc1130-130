﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace employeeManagementCRUD.Models
{
    public class Employee
    {
        #region Properties
        public int empNo { get; set; }
        public string empName { get; set; }
        public string empDesignation { get; set; }
        public int empSalary { get; set; }
        public bool empIsPermenant { get; set; }
        #endregion

        static List<Employee> eList = new List<Employee>()
        {
            new Employee(){empNo=101, empName="Karan", empDesignation="Sales", empIsPermenant=true, empSalary=5000},
            new Employee(){empNo=102, empName="Sumit", empDesignation="Sales", empIsPermenant=true, empSalary=5000},
            new Employee(){empNo=103, empName="Akshay", empDesignation="Sales", empIsPermenant=true, empSalary=5000},
            new Employee(){empNo=104, empName="Rohan", empDesignation="Sales", empIsPermenant=true, empSalary=5000},
        };

        public List<Employee> GetAllEmployees()
        {
            return eList;
        }


        public string AddEmployee(Employee newEmp)
        {
            //do ur validations here
            eList.Add(newEmp);
            return "Employee Added Successfully";
        }

        public string UpdateEmployee(Employee changes)
        {
            var emp = (from e in eList
                       where e.empNo == changes.empNo
                       select e).Single();

            emp.empName = changes.empName;
            emp.empDesignation = changes.empDesignation;
            emp.empSalary = changes.empSalary;
            emp.empIsPermenant = changes.empIsPermenant;

            return "Employee Details Updated";
        }

        public string Deleteemployee(int empNo)
        {
            var emp = (from e in eList
                       where e.empNo == empNo
                       select e).Single();

            eList.Remove(emp);
            return "Employee Deleted Successfully";


        }
        








    }
}
