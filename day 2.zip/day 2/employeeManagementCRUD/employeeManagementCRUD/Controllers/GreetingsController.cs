﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace employeeManagementCRUD.Controllers
{
    public class GreetingsController : Controller
    {
    
       public IActionResult Greet()
        { 
           return View();
        }

        [HttpPost]
        public IActionResult Greet(string guestName)
        {
            ViewBag.message = "Hello " + guestName + " Welcome to MVC world";
            //we can pass the data to model from here, but calling the model method
            return View();
        }


        public IActionResult Calculate()
        {
            ViewBag.hasError = false;
            ViewBag.hasResult = false;
            return View();
        }

        [HttpPost]
        public IActionResult Calculate(int num1, int num2)
        {
            if (num1 == 0 || num2 == 0)
            {
                ViewBag.hasError = true;
                ViewBag.hasResult = false;
                ViewBag.errMessage = "Please Enter Values greater than Zero";
            }
            else if (num1 < num2)
            {
                ViewBag.hasError = true;
                ViewBag.hasResult = false;
                ViewBag.errMessage = "This will result in negative value, we do not process negative values";
            }
            else
            {
                ViewBag.hasError = false;
                ViewBag.hasResult = true;
                ViewBag.addition = num1 + num2;
                ViewBag.subtraction = num1 - num2;
                ViewBag.division = num1 / num2;
                ViewBag.multipication = num1 * num2;
            }
            return View();
        }





    }
}