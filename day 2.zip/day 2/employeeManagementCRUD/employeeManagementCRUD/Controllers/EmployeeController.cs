﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using employeeManagementCRUD.Models;
namespace employeeManagementCRUD.Controllers
{
    public class EmployeeController : Controller
    {
        Employee empObj = new Employee(); //this will change to dependency injection later

        public IActionResult Employeelist()
        {
            ViewBag.empList = empObj.GetAllEmployees();
            return View();
        }

        public IActionResult AddEmployee()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddEmployee(Employee newEmp)
        {
          ViewBag.result =   empObj.AddEmployee(newEmp);
            return RedirectToAction("Employeelist");
            
        }
    
    }
}